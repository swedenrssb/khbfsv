package TestRun;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\Features\\elearningProfileEdit.feature","src\\test\\java\\Features\\CalculatorBMI.feature"},
glue = {"StepDefination"},
tags = {"@Regression"}

)
public class RunnerClass {

}
